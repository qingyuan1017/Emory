public class course {
	
	public course(String n) {

	}
	
	public void setDay(int[] d) {

	}
	
	public void setTime(int s, int e) {

	}
	
	public String toString() {
		return "Course";
	}
}
