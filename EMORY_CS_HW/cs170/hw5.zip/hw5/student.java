public class student {
	public student(String n) {

	}

	public void add(course c) {

	}
	
	public String toString() {
		return "Student";
	}
}
