public class SwitchTest {
	public static void main(String[] args) {

		String a = "hello";
		switch(a) {
			case "hello":
				System.out.println(a);
				break;
			default:
				break;
		}
	}
}
