//
//  main.c
//  CS450
//
//  Created by LS on 9/15/14.
//  Copyright (c) 2014 Emory University. All rights reserved.


#include <stdio.h>
#include <stdlib.h>

//#define DE


int main(int argc, const char * argv[])
{
    
    char ptr[80];
    int x = 8;
    int y;
    #ifdef DEBUG
        printf("%s", "abc");
    #endif
    sprintf(ptr, "%d", x);
    sscanf(ptr, "%d", &y);
    
    // insert code here...
    printf("Hello, World!%d\n", y);
    return 0;
}

