//
//  goldbach.c
//  CS450
//
//  Created by Liqi Shu on 9/15/14.
//Liqi Shu
//liqi.shu@emory.edu/ lshu2
//I worked on this assignment alone, using only this semester's course materials.
//

#include <stdlib.h>
#include <stdio.h>
//#include "header.h"

#define BITSPERSEG  (8*256*sizeof(int))

typedef struct _seg {  /* definition of new type "seg" */
    int  bits[256];
    struct _seg  *next,*prev;
} seg;


void clearbits(int N);
void sieve( int N );
void setBit(int n);
//int testBit(int n);
seg *whichseg(int j);
int whichint(int j);
int whichbit(int j);
int  countPrimes( int N );
void factor(int inp);
seg *traverse(int k);
seg *head;

/*


int main(int argc, char *argv[]) {
    
	seg *pt;
	int	N, Nsegs, numOfPrimes, input, i;  //N is the input num, Nsegs is num of segs, numOfPrimes is the number of primes below N, input is the input number to be factored
    
    if (argc == 2) sscanf(argv[1],"%d",&N);
    else scanf("%d",&N);  //read in max number
	Nsegs = ((N+1)/2 +BITSPERSEG -1)/BITSPERSEG;  //calc num of segs
    
    
    
	head = NULL;
    pt = (seg *) malloc(sizeof (seg));
    head = pt;
	for (i=1;i<Nsegs;i++) { 
		pt->next = (  seg *) malloc(sizeof (seg));
        pt->next->prev = pt;
        pt=pt->next;
    }
    
	// clear (initialize) all bits
    
	clearbits(Nsegs);
    
    sieve(N); //input the max number %^&*(*&^%$%^&*
    
    numOfPrimes = countPrimes(N);    //print "The number of odd primes less than or equal to N is: XXXX"
    
    printf("The number of odd primes less than or equal to %d is %d\n", N, numOfPrimes);
    printf("Enter Even Numbers >= 5 for Goldbach Tests\n");
    
    while (1)
    {
        if ( scanf("%d", &input) == EOF)
            break;
        factor(input);
    }
}

void clearbits(int Nsegs) { // clear all bits at once
	int i,j;
    seg* p = head;
	for (i=0; i< Nsegs || p != NULL; i++) {    //traverse all segments
		for (j=0; j<= 255; j++)  //fill whole seg with 0s
			p->bits[j]=0;
		p=p->next;
	}
}

void sieve(int N){
    seg* p = head;
    p->bits[0] |= 1<< 0;
    
    //setBit(1);	//initialize
    
    int Nsegs = ((N+1)/2 +BITSPERSEG -1)/BITSPERSEG;
//    N = (N-1)/2;
    int L = 1;
    int i,j,k;
    for (i=0; i< Nsegs || p != NULL; i++) {    //traverse all segments
        for (j=0; j<= 255; j++)  //j is int
            for (k=0; k<32 && L*L <= N;k++) //k is bit
            {
                if(!(p->bits[j] & 1 << k)) {
                    int l = L*L;	//start from i^2, eliminate with increment 2i
                    //I
                    seg *p_s = whichseg((l-1)/2);
                    int int_s = whichint((l-1)/2);
                    int bit_s = whichbit((l-1)/2);
                    
//                    for (l = L*L; l <= N; l += 2*L){
//                        setBit(l);
//                    }
                    while(p_s != NULL){
                        p_s->bits[int_s] |= 1 << (bit_s);
                        if(bit_s + L > 31)
                        {
                            if(int_s == 255)
                            {
                                p_s=p_s->next;
                                int_s = 0;
                                bit_s = (bit_s+L)%32;
                            }
                            else {
                                int_s++;
                                bit_s = (bit_s+L)%32;
                            }
                        }
                        else{
                            bit_s += L;
                        }
                    }
                }
                L+=2;
            }
        p=p->next;
    }
    
//    
//    int i;
//    for (i = 1; i*i <= N; i += 2){	//traverse only odd numbers up to square root of n
//        int n = (i-1)/2;
//        if (!(whichseg(n)->bits[whichint(n)] & 1 << whichbit(n))){	//if i is prime number
//            int j;	//start from i^2, eliminate with increment 2i
//            for (j = i*i; j <= N; j += 2*i){
//                setBit(j);
//            }
//        }
//    }
}

void setBit(int n){
    n = (n-1)/2;    //change odd number n to bit position n
    whichseg(n)->bits[whichint(n)] |= 1 << (whichbit(n)); //set the pos of n in seg to 1
}



//int testBit(int n){
//    n = (n-1)/2;    //change odd number n to bit position n
//    return ((whichseg(n)->bits[whichint(n)] & 1 << whichbit(n)) == 0) ? 1 : 0;   //return the value of n in seg, if 0 return 1 (prime), else return 0 (composite)
//}


seg* whichseg(int j){
    //seg *p = traverse(n/BITS_PER_SEG);
    int i;
    seg* p = head;
    for (i = 0; i < j/BITSPERSEG; i++)    //get the seg *p that n is located
        p = p->next;
    return p;
}

int whichint(int j){
    return j%BITSPERSEG/32;
}

int whichbit(int j){
    return j%32;
}

int countPrimes(int N){
    int count = 0;
    int Nsegs = ((N+1)/2 +BITSPERSEG -1)/BITSPERSEG;
    N = (N-1)/2;
    int i,j,k;
    seg* p = head;
    for (i=0; i< Nsegs || p != NULL; i++) {    //traverse all segments
        for (j=0; j<= 255; j++)  //j is int
            for (k=0; k<32 && N >= 0;k++) //k is bit
            {
                if((p->bits[j] & 1 << k) == 0)  count++;
                N--;
            }
        p=p->next;
    }
//    if (N >= 2) count++;	//include prime number 2
//    int i;	//traverse only odd numbers
//    for (i = 1; i <= N; i += 2)
//        if (testBit(i) != 0)
//            count++;
    return count;
}


void factor(int inp){
    
     //If inp is an odd number, one of the decomposition values I and K-I will have an even number.
     //Therefore, the valid decomposition has to be K = 2 + (K-2).
     //Otherwise, it is not decomposable.
     //If inp is an even number, both decomposition values have to be odd numbers to be prime numbers except 4 as an input.
     //And the smallest prime number 3 is in the bitmaps, so we can do testBit to test the decomposition
    
    if ( inp < 2 )
        exit(1);
    else if (inp < 4)
        printf(" %d =  0 + %d \n", inp, inp);
    else if ( inp%2 != 0 || inp == 4){
        int n = ((inp-2)-1)/2;
        if (!(whichseg(n)->bits[whichint(n)] & 1 << whichbit(n)) || inp == 4)
            printf(" %d =  2 + %d \n", inp, inp-2);
        else    printf(" %d =  0 + %d \n", inp, inp);
    }
    else {
        int i = (inp/2%2 == 0) ? inp/2-1 : inp/2;
        //I
        seg *p_back = whichseg((i-1)/2);
        int int_back = whichint((i-1)/2);
        int bit_back = whichbit((i-1)/2);
        //K-I
        seg *p_forward = whichseg((inp-i-1)/2);
        int int_forward = whichint((inp-i-1)/2);
        int bit_forward = whichbit((inp-i-1)/2);
        
        while (1){
            while(p_back->bits[int_back] & 1 << bit_back){
                if(bit_back == 0)
                {
                    if(int_back == 0)
                    {
                        if(p_back->prev == NULL)
                        {
                            printf(" %d = 0 + %d    **This integer cannot be decomposed\n", inp, inp);
                            exit(1);
                        }
                        else{
                            p_back = p_back->prev;
                            int_back = 255;
                            bit_back = 31;
                        }
                    }
                    else {
                        int_back--;
                        bit_back = 31;
                    }
                }
                else{
                    bit_back--;
                }
                i -= 2;
                if(bit_forward == 31)
                {
                    if(int_forward == 255)
                    {
                        if(p_forward->next == NULL)
                        {
                            printf(" %d = 0 + %d    **This integer cannot be decomposed\n", inp, inp);
                            exit(1);
                        }
                        else{
                            p_forward = p_forward->next;
                            int_forward = 0;
                            bit_forward = 0;
                        }
                    }
                    else {
                        int_forward++;
                        bit_forward = 0;
                    }
                }
                else{
                    bit_forward++;
                }
            }
            if(!(p_forward->bits[int_forward] & 1 << bit_forward)){
                printf(" %d =  %d + %d \n", inp, i, inp-i);
                break;
            }
            if(bit_back == 0)
            {
                if(int_back == 0)
                {
                    if(p_back->prev == NULL)
                    {
                        printf(" %d = 0 + %d    **This integer cannot be decomposed\n", inp, inp);
                        exit(1);
                    }
                    else{
                        p_back = p_back->prev;
                        int_back = 255;
                        bit_back = 31;
                    }
                }
                else {
                    int_back--;
                    bit_back = 31;
                }
            }
            else{
                bit_back--;
            }
            i -= 2;
            if(bit_forward == 31)
            {
                if(int_forward == 255)
                {
                    if(p_forward->next == NULL)
                    {
                        printf(" %d = 0 + %d    **This integer cannot be decomposed\n", inp, inp);
                        exit(1);
                    }
                    else{
                        p_forward = p_forward->next;
                        int_forward = 0;
                        bit_forward = 0;
                    }
                }
                else {
                    int_forward++;
                    bit_forward = 0;
                }
            }
            else{
                bit_forward++;
            }
        }
    }
}

*/
