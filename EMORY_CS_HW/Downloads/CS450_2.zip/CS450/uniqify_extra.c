////
////  uniqify.c
////  CS450
////
////  Created by Liqi Shu on 11/1/14.
////  liqi.shu@emory.edu/ lshu2
////  I worked on this assignment alone, using only this semester's course materials.
////  Copyright (c) 2014 Emory University. All rights reserved.
////
//
//#include <sys/types.h>
//#include <fcntl.h>
//#include <stdlib.h>
//#include <unistd.h>
//#include <stdio.h>
//#include <errno.h>
//#include <sys/wait.h>
//#include <ctype.h>
//#include <string.h>
//
//
//#define maxWordLength 80
//#define sorter "/bin/sort"
//#define numSorter 2
//
//
//int main(int argc, char * argv[]){
//    static int i = 0, j = 0, k = 0; /* generic counter, and parser input */
//    FILE *stream[numSorter][2]; /* [0][0] for S1 input, [0][1] for S2 input, [1][0] for S1 output, [1][1] for S2 output */
//    int pid[1+numSorter];				/*pids of children, [0] for S1, [1] for S2, [3] for Suppressor*/
//    int whom;				/* pid of dead child*/
//    int status;				/* childs return status*/
//    int pipefd[numSorter][2][2];			/* fds for ends of two pipes, fd[0] for S1, fd[1] for S2 */
//    
//    
//    /* before forking set up the two pipes
//     ** pipefd[0] is parser to sorter, pipefd[1] is sorter to suppressor
//     ** pipefd[i][0] is read end,  pipefd[i][1] is write end
//     */
//    for (j=0; j<numSorter; j++){
//        for (i=0; i<2; i++) {
//            if (pipe(pipefd[j][i]) == -1) {
//                perror("pipe");
//                exit(i+j*numSorter+0*2*numSorter+1);
//            }
//        }
//    }
//    
//    /* forking, pid[0] is the sorter child, pid[1] the suppressor child */
//    for (i=0; i< (1+ numSorter); i++) {
//        if ((pid[i]=fork()) ==  -1) {
//            perror("fork");
//            exit (i+1*4+1);
//        }
//        if (pid[i] == 0) {
//            /* this is the child*/
//            
//            /* sorter will sort all input and output it to suppressor to eliminate duplicates*/
//            if (i < numSorter) { /* sorter does this */
//                /* Close pipe ends*/
//                for (j=0; j<numSorter; j++)
//                {
//                    if (j == i){
//                        close (pipefd[j][0][1]); close (pipefd[j][1][0]);
//                    }
//                    else  {
//                        for (k=0; k<2;k++){
//                            close (pipefd[j][k][1]); close (pipefd[j][k][0]);
//                        }
//                    }
//                }
//                /* Redirect stdin & stdout */
//                dup2 (pipefd[i][0][0], STDIN_FILENO);
//                dup2 (pipefd[i][1][1], STDOUT_FILENO);
//                /* Exec the sort program */
//                execl(sorter, sorter, NULL);
//                perror("execl"); /* shoudn't get here */
//                exit(i+2*2*numSorter+1);
//            }
//            if (i==numSorter) { /* suppressor does this */
//                for (j=0; j<numSorter; j++)
//                {
//                    /* Close pipe ends*/
//                    close (pipefd[j][0][0]); close (pipefd[j][0][1]); close (pipefd[j][1][1]);
//                    /* Associate pipe */
//                    stream[j][1] = fdopen (pipefd[j][1][0], "r");
//                    if (stream[j][1] == NULL) {
//                        perror("redirect fd2 stdin");
//                        exit (i+j*2+3*2*numSorter+1);
//                    }
//                }
//                char prevBuf[maxWordLength+1] = "\n";
//                char currentBuf[maxWordLength+1] = "";
//                int pipeEnd[2] = {0, 0};
//                int minBuf = 0;
//                char buffer[numSorter][maxWordLength+1];
//                
//                for (j=0; j<numSorter;j++)
//                {
//                    if (fgets(buffer[j], maxWordLength, stream[j][1]) == NULL)
//                            pipeEnd[j] = 1;
//                    buffer[j][maxWordLength] = '\0';
//                }
//                
//                while (!pipeEnd[0] || !pipeEnd[1])
//                {
//                    for (j=0; j<numSorter;j++)
//                    {
//                        while (!pipeEnd[j] && strcmp (buffer[j], prevBuf) == 0){
//                            if (fgets(buffer[j], maxWordLength, stream[j][1]) == NULL)
//                                pipeEnd[j] = 1;
//                        }
//                    }
//                    buffer[j][maxWordLength] = '\0';
//                    if (!pipeEnd[0] && !pipeEnd[1]){
//                        minBuf = (strcmp (buffer[0], buffer[1]) <= 0) ? 0:1;
//                        strcpy(currentBuf, buffer[minBuf]);
//                    }
//                    else if (pipeEnd[0] && !pipeEnd[1])
//                    {
//                        strcpy(currentBuf, buffer[1]);
//                        minBuf = 1;
//                    }
//                    else if (!pipeEnd[0] && pipeEnd[1])
//                    {
//                        strcpy(currentBuf, buffer[0]);
//                        minBuf = 0;
//                    }
//                    else break;
////                    printf("##%d##%d##%d##%s//%s//%s//%s", pipeEnd[0],pipeEnd[1],minBuf, currentBuf, prevBuf, buffer[0], buffer[1]);
//                    if (!pipeEnd[minBuf] && fgets(buffer[minBuf], maxWordLength, stream[minBuf][1]) == NULL)
//                    {
//                        pipeEnd[minBuf] = 1;
//                    }
//                    buffer[minBuf][maxWordLength] = '\0';
//                    printf("%s",currentBuf);
//                    strcpy(prevBuf, currentBuf);
//                }
//                for (j=0; j<numSorter;j++){
//                    fclose (stream[j][1]);
//                    close (pipefd[j][1][0]);
//                }
//            }
//            exit (0); /* either way exit */
//        }
//    }
//    
//    
//    /* this is the parent*/
//    for (j=0; j<numSorter;j++){
//        /* Close pipe ends*/
//        close(pipefd[j][0][0]); close(pipefd[j][1][0]); close(pipefd[j][1][1]);
//        /* Associate pipe */
//        if ((stream[j][0] = fdopen(pipefd[j][0][1], "w")) == 0) {
//            perror("redirect fd1 stdout");
//            exit (i+4*2*numSorter+1);
//        }
//    }
//
//    int parsePrevC = 0, parseC;
//    k = 0;
//    int counter = 0;
//    while ((parseC = fgetc(stdin)) != EOF)
//    {
//        k %= numSorter;
//        if (counter == maxWordLength){
//            fputc('\n', stream[k++][0]);
//            counter = 0;
//            if (isalpha(parseC))
//            {
//                fputc(tolower(parseC), stream[k%numSorter][0]);
//                counter++;
//            }
//        }
//        else if (isalpha(parseC))
//        {
//            fputc(tolower(parseC), stream[k][0]);
//            counter++;
//        }
//        else if (!isalpha (parseC) && isalpha(parsePrevC))
//        {
////            char str[15];
////            sprintf(str, "%d", k);
////            fputs(str, stream[k][0]);
//            fputc('\n', stream[k++][0]);
//            counter = 0;
//        }
//        parsePrevC = parseC;
//    }
//    for (j=0; j<numSorter;j++){
//        fclose(stream[j][0]);
//        close(pipefd[j][0][1]);
//    }
//    
//    /* now parent waits */
//    for (i=0; i<1+numSorter; i++ ) {
//        if ((whom=wait(&status)) == -1) {
//            perror("wait");
//            exit(i+5*2*numSorter+1);
//        }
//    }
//    return 0;
//}