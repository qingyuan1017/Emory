public class selectionSort {
	public static void printArray(double[] a) {
                if(a == null)
                        return;

                for(int i = 0; i < a.length; i++) {

                        if(i < a.length - 1)
                                System.out.print(a[i] + ", ");
                        else
                                System.out.println(a[i]);
                }


        }

	public static double[] init() {
		double[] a = new double[]{3.5, 1.2, 8.9, 11.0, 5.9};
		return a;
	}

	public static void swap(double a, double b) {
		double temp = a;
		a = b;
		b = temp;
	}

	public static double[] swap(double[] a, int i, int k) {
		double temp = a[i];
		a[i] = a[k];
		a[k] = temp;

		return a;
	}

	public static void main(String[] args) {
		double[] a = null;

		a = init();

		for(int i = 0; i < a.length - 1; i++) {
			int k = i;			
			for(int j = i; j < a.length; j++) {
				if(a[j] < a[k])
					k = j;
			}
			
			a = swap(a, i, k);
		}

		printArray(a);
	}
}
