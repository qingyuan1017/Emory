import java.util.Scanner;

public class scan {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		//int i = input.nextInt();
		String d = "hello\\ world";
		System.out.println("The result is: " + d);
	}
}
