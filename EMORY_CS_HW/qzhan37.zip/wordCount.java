public class wordCount {
	public static String[] wordSet = null;
	public static int[] count = null;
	public static int numOfWord = 0;

	public static void addNewWord(String w) {
		if(wordSet == null) {
			wordSet = new String[1];
			count = new int[1];
			wordSet[0] = w;
			count[0] = 1;
			numOfWord++;
			return;
		}

		int pos = getPosition(w);
		if(pos >= 0) {
			count[pos]++;
		}
		else {
			if(numOfWord >= wordSet.length) {
				String[] temp_wordSet = new String[wordSet.length * 2];
				for(int i = 0; i < wordSet.length; i++) {
					temp_wordSet[i] = wordSet[i];
				}
				wordSet = temp_wordSet;

				int[] temp_count = new int[count.length * 2];
				for(int i = 0; i < count.length; i++) {
					temp_count[i] = count[i];
				}
				count = temp_count;
			}
			wordSet[numOfWord] = w;
			count[numOfWord]++;

			numOfWord++;
		}
		

	}

	public static int getPosition(String w) {
		if(wordSet == null) {
			return -1;
		}

		for(int i = 0; i < numOfWord; i++) {
			if(wordSet[i].equals(w))
				return i;
		}

		return -1;
	}

	public static void printAll() {
		if(wordSet == null)
			return;

		for(int i = 0; i < numOfWord; i++) {
			System.out.println(wordSet[i] + ": " + count[i]);
		}
	}


	public static void main(String[] args) {
		String[] a = new String[]{"aa", "bb", "aa", "cc", "aa", "cc"};
		
		for(int i = 0; i < a.length; i++) {
			addNewWord(a[i]);
		}
		
		printAll();
	}
}
