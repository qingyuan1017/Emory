import java.util.Scanner;
import java.io.*;

public class CallFunction {
	public static int num;
	public static String path_to_file = "/home/cs170001/share/hw/grade.txt";

	/*
	public static String readString() {
		File f = new File(path_to_file);
		Scanner in = new Scanner(f);
		return "hello";
	}
	*/

	public static void main(String[] args) throws IOException {
		Tools.money = 10;

		System.out.println(Tools.money);
		
		for(int i = 0; i < 5; i++) {
			Tools.increaseOne();
		}

		System.out.println(Tools.money);

		for(int i = 0; i < 5; i++) {
			Tools.increaseTwo();
		}

		System.out.println(Tools.money);
	}
}

