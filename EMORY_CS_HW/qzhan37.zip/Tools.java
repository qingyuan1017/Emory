import java.util.Scanner;

public class Tools {
	public static int money = 0;

	public static int readInt(Scanner in) {
		if(in.hasNextInt())
			return in.nextInt();
		else
			return -1;
	}
	public static String readString(Scanner in) {
		return in.next();
	}
	public static void main(String[] args) {
		System.out.println("hi");
	}

	public static void increaseOne() {
		money += 1;
	}

	public static void increaseTwo() {
		money += 2;
	}
}
