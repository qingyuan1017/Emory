import java.io.*;
import java.util.Scanner;

public class arrayExample {	

	public static void addOne(int a) {
		a += 1;
	}

	public static void addOne(int[] a) {
		if(a == null)
			return;
		
		for(int i = 0; i < a.length; i++) {
			a[i] += 1;
		}
	}

	public static void makeNewArray(int[] a) {
		a = new int[2];
	}
	
	public static void printArray(int[] a) {
		if(a == null)
			return;
		
		for(int i = 0; i < a.length; i++) {
			
			if(i < a.length - 1)
				System.out.print(a[i] + ", ");
			else
				System.out.println(a[i]);
		}

		
	}

	
	public static void main(String[] args) throws IOException {
		
		//printArray(a);
		//System.out.println(a);

		int b = 15;
		addOne(b);

		System.out.println(b);

		int[] a = new int[]{4, 3, 9, 10, 2};
		//addOne(a);
		makeNewArray(a);
		printArray(a);
		
	}
}

