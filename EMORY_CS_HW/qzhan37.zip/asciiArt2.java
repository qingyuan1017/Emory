import java.util.Scanner;

public class asciiArt2 {

	public static void printLine(int num_space, int num_char, char c) {
		for(int i = 0; i < num_space; i++)
			System.out.print(" ");
		
		for(int i = 0; i < num_char; i++)
			System.out.print(c);

		System.out.println();	
	}

        public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();

                for(int i = 0; i < n; i++) {
                        printLine(n - i - 1 + 10, i * 2 + 1, '*');
                }
        }
}
