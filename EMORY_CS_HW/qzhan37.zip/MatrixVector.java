public class MatrixVector {
	
	public static void main(String[] args) {
		double[][] a = new double[5][];
		for(int i = 0; i < a.length; i++) {
			a[i] = new double[i + 10];
		}

		for(int i = 0; i < a.length; i++) {
			for(int j = 0; j < a[i].length; j++) {
				a[i][j] = i + j;
			}
		}

		for(int i = 0; i < a.length; i++) {
			for(int j = 0; j < a[i].length; j++) {
				System.out.print(a[i][j] + " ");
			}
			System.out.println();
		}
	}
}
