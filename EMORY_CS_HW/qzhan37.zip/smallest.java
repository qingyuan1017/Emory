import java.util.Scanner;

public class smallest {

	public static int min(int a, int b) {
		if(a > b)
			return b;
		else
			return a;
	}

	public static double min(int a, int b) {
		if(a > b)
			return b;
		else
			return a;
	}
	
	public static int max(int a, int b) {
		if(a > b)
			return a;
		else
			return b;
	}

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		double a = in.nextDouble();
		double b = in.nextDouble();
		double c = in.nextDouble();

		int r;

		/*
		if(a > b)
			r = b;
		else
			r = a;

		if(r > c)
			r = c;
		*/

		r = min(a, b);
		r = min(r, c);

		System.out.println(r);

		int l = max(a, b);
		l = max(l, c);

		System.out.println(l);
	}

}
