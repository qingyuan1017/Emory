public class vectorExample {
	public static double[] addVector(double[] a, double[] b) {
		double[] c = new double[a.length];
		for(int i = 0; i < c.length; i++) {
			c[i] = a[i] + b[i];
		}
		return c;
	}
	public static double[] subtractVector(double[] a, double[] b) {
		double[] c = new double[a.length];
		for(int i = 0; i < c.length; i++) {
			c[i] = a[i] - b[i];
		}
		return c;
	}
	public static double dot(double[] a, double[] b) {
		double sum = 0.0;
		for(int i = 0; i < a.length; i++)
			sum += a[i] * b[i];
		return sum;
	}
	public static double norm(double[] a) {
		double sum = 0.0;
		for(int i = 0; i < a.length; i++)
			sum += a[i] * a[i];
		return Math.sqrt(sum);
	}
	public static void printArray(double[] a) {
		for(int i = 0; i < a.length; i++)
			System.out.print(a[i] + " ");
		System.out.println();
	}
	public static void main(String[] args) {
		double[] a = new double[]{1.0, 2.0};
		double[] b = new double[]{-2.0, 1.0};
		
		System.out.println(dot(a, b));
		System.out.println(norm(a));
		System.out.println(norm(b));

		double cos = dot(a, b) / norm(a) / norm(b);
		double angle = Math.acos(cos);
		double degree = angle / Math.PI * 180;

		System.out.println(degree);
	}
}
