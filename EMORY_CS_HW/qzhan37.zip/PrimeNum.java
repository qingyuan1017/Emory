import java.util.Scanner;

public class PrimeNum {

	public static boolean isPrime(int n) {
		for(int j = 2; j * j <= n; j++) {
			if(n % j == 0) {
				return false;
			}
		}

		return true;
	}

	public static void printPrime() {
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		
		for(int i = 2; i <= n; i++) {
			if(isPrime(i))
				System.out.println(i);
		}
	}

	public static void main(String[] args) {
		printPrime();
	}
}
