public class arrayDoubling {
	public static int[] a = null;
	public static int count = 0;

	public static void printArray() {
		if(a == null)
                        return;

                for(int i = 0; i < count; i++) {

                        if(i < count - 1)
                                System.out.print(a[i] + ", ");
                        else
                                System.out.println(a[i]);
                }
	}

      
	public static void main(String[] args) {
		int num = Integer.parseInt(args[0]);

		a = new int[1];

		for(int i = 0; i < num; i++) {
			int x = (int)(Math.random() * 100);
			
			if(i == a.length) {
				int[] b = new int[a.length * 2];

				for(int j = 0; j < a.length; j++) {
					b[j] = a[j];
				}
				
				a = b;
			}
			
			a[i] = x;
			
			count++;
		}

		printArray();

	}
}
