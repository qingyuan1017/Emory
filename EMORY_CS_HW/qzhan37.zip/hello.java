public class hello {
	public static void main(String[] args) {
		int d = -898;
		char c = (char)d;

		System.out.println(c);
	}
}
